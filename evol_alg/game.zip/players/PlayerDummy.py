import numpy as np
import playerConfig


class Player():
 def __init__(self):
  return

 def Step(self,step=0,own_state=[],known_state_opponent=[]):
  return np.random.randint(0,3)
